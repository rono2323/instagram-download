// Mock payment utility — replace with real gateway integration
window.PaymentUtils = {
  async processPayment(cardData) {
    // very simple validation
    if (!cardData.number || cardData.number.length < 12) {
      return Promise.reject(new Error('Invalid card number'));
    }
    // simulate network call
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ status: 'ok', transactionId: 'tx_' + Date.now() });
      }, 900);
    });
  }
};