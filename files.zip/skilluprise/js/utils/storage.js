// Simple localStorage wrapper
window.AppStorage = {
  prefix: 'skilluprise:',
  set(key, value) {
    try {
      localStorage.setItem(this.prefix + key, JSON.stringify(value));
    } catch (e) { console.warn('Storage set failed', e); }
  },
  get(key) {
    try {
      const v = localStorage.getItem(this.prefix + key);
      return v ? JSON.parse(v) : null;
    } catch (e) { return null; }
  },
  remove(key) {
    try { localStorage.removeItem(this.prefix + key); } catch (e) {}
  }
};