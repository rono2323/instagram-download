// Certificate helper (placeholder)
window.CertificateUtils = {
  generateTextCertificate(user, testName) {
    return `Certificate of Completion\n\nName: ${user.name}\nTest: ${testName}\nDate: ${new Date().toLocaleDateString()}`;
  }
};