// Simple URL helper
window.Nav = {
  getQueryParam(name) {
    return new URLSearchParams(location.search).get(name);
  }
};