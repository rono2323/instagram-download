// TEST DATA: java.js
var TEST_DATA = [
  {
    question: "Which package contains the Scanner class?",
    options: ["java.util", "java.lang", "java.io", "java.net"],
    answer: "java.util"
  },
  {
    question: "What is the size of int in Java?",
    options: ["16-bit", "32-bit", "64-bit", "Depends on OS"],
    answer: "32-bit"
  }
];