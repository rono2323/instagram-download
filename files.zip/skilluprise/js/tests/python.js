// TEST DATA: python.js
// Expose TEST_DATA array for the test loader to consume
var TEST_DATA = [
  {
    question: "What is the output of: print(2 * 3 + 1)?",
    options: ["7", "8", "6", "5"],
    answer: "7"
  },
  {
    question: "Which keyword is used to create a function in Python?",
    options: ["func", "def", "function", "lambda"],
    answer: "def"
  }
];