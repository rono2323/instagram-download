// Main entry used on every page
document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Simple client-side router-ish: run page-specific init if present.
  if (window.pageInit && typeof window.pageInit === 'function') {
    window.pageInit();
  }
});