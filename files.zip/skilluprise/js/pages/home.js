// home.js mounts test cards into #test-list
window.pageInit = () => {
  const list = document.getElementById('test-list');
  if (!list) return;

  const tests = [
    { id: 'python', title: 'Python Basics', description: 'Fundamentals of Python.' },
    { id: 'java', title: 'Java Core', description: 'Core Java concepts.' }
  ];

  list.innerHTML = '';
  tests.forEach(t => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <h3>${t.title}</h3>
      <div class="meta">${t.description}</div>
      <div class="actions">
        <a class="btn" href="test.html?test=${t.id}">Start Test</a>
      </div>
    `;
    list.appendChild(card);
  });
};