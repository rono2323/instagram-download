// test.js loads test data based on query param and renders simple questions
window.pageInit = () => {
  const getParam = (k) => new URLSearchParams(location.search).get(k);
  const testId = getParam('test') || 'python';
  const titleEl = document.getElementById('test-title');
  if (titleEl) titleEl.textContent = `Test — ${testId}`;

  // load test module (simple dynamic loader)
  const testPath = `js/tests/${testId}.js`;
  fetch(testPath).then(resp => resp.text()).then(code => {
    // Evaluate in a safe-ish scope to get questions variable exported as window.TEST_DATA
    try {
      const wrapped = `(function(){ ${code}; return typeof TEST_DATA !== 'undefined' ? TEST_DATA : null })()`;
      const data = eval(wrapped);
      renderTest(data || []);
    } catch (err) {
      console.error('Failed to load test', err);
      document.getElementById('test-area').innerText = 'Failed to load test.';
    }
  });

  function renderTest(questions) {
    const area = document.getElementById('test-area');
    area.innerHTML = '';
    if (!questions.length) {
      area.innerText = 'No questions available.';
      return;
    }
    const form = document.createElement('form');
    questions.forEach((q, i) => {
      const field = document.createElement('div');
      field.className = 'card';
      field.innerHTML = `<p><strong>${i+1}. ${q.question}</strong></p>`;
      q.options.forEach((opt, j) => {
        const id = `q${i}_o${j}`;
        const optEl = document.createElement('label');
        optEl.innerHTML = `<input type="radio" name="q${i}" value="${opt}" id="${id}"> ${opt}`;
        field.appendChild(optEl);
      });
      form.appendChild(field);
    });
    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'btn';
    submit.textContent = 'Submit';
    form.appendChild(submit);

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Submitted (scoring is not implemented in starter)');
    });

    area.appendChild(form);
  }
};