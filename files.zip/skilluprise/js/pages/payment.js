// payment page logic — uses utils/payment.js to simulate a payment
window.pageInit = () => {
  const form = document.getElementById('payment-form');
  const result = document.getElementById('payment-result');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      name: form.cardName.value,
      number: form.cardNumber.value,
      expiry: form.expiry.value,
      cvc: form.cvc.value
    };
    result.classList.remove('hidden');
    result.innerText = 'Processing...';
    try {
      const res = await window.PaymentUtils.processPayment(data);
      result.innerText = 'Payment success: ' + JSON.stringify(res);
    } catch (err) {
      result.innerText = 'Payment failed: ' + (err.message || err);
    }
  });
};