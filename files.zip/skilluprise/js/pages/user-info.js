// user-info.js saves user info to localStorage
window.pageInit = () => {
  const form = document.getElementById('user-form');
  if (!form) return;

  const storage = window.AppStorage || null;
  // load
  if (storage && storage.get) {
    const data = storage.get('user') || {};
    form.name.value = data.name || '';
    form.email.value = data.email || '';
    form.phone.value = data.phone || '';
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const user = {
      name: form.name.value,
      email: form.email.value,
      phone: form.phone.value
    };
    if (storage && storage.set) storage.set('user', user);
    alert('Saved');
  });
};