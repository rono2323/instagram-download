// certificate page logic — generates simple certificate from stored user data
window.pageInit = () => {
  const preview = document.getElementById('certificate-preview');
  const btn = document.getElementById('download-cert');
  const user = window.AppStorage.get('user') || { name: 'Candidate' };
  preview.innerHTML = `
    <div class="card" style="text-align:center;padding:2rem;">
      <h2>Certificate of Completion</h2>
      <p>This certifies that</p>
      <h3>${user.name}</h3>
      <p>has successfully completed the test</p>
      <p><em>SkillUprise</em></p>
    </div>
  `;

  btn.addEventListener('click', () => {
    const text = `Certificate: ${user.name} — SkillUprise`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${user.name}-certificate.txt`;
    a.click();
    URL.revokeObjectURL(url);
  });
};